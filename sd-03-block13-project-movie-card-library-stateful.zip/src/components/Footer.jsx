import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <div className="footer">
        <p>
          Movie Library em React com uso de Estado, por Luma Arruda para Trybe.
        </p>
      </div>
    );
  }
}

export default Footer;
